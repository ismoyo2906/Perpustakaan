<!DOCTYPE html>
<html lang="en">
<head>
<!---
Rich Text
-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap-3.2.0/dist/css/bootstrap.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/font-awesome-4.1.0/css/font-awesome.min.css')?>">
<!-- include summernote css/js-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/dist/summernote.css'?>">

<!---
    Summernote Rich Text Editor Example with PHP & Mysql
    http://hackerwins.github.io/summernote/
-->
</head>