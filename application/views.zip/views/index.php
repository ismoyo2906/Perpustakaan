<!doctype html>
<html>
<head>
<title>Aplikasi Perpustakaan</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css.map')?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/datatable/datatables.css'?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/footer-ind2906.css'?>">

</head>
	
<body>
	<nav class="navbar navbar-default">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
				<a class="navbar-brand" href="<?php echo base_url().''; ?>">Perpustakaan</a>
			</div>
		<div class="collapse navbar-collapse" id="bs-examplenavbar-collapse-1">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="<?php echo base_url().'welcome/login'; ?>"><span class="glyphicon glyphicon-log-in"></span> Login / Daftar </a></li>
			</ul>
		</div>
	</div>
	</nav>
<br>
<br>
<center>
<div class="text">
	<br>
	<b>
	<h2>APLIKASI PERPUSTAKAAN</h2>
	<h4>Mempercepat penemuan penelitian untuk membentuk masa depan yang lebih baik</h4>
			<h3>Penelitian hari ini, inovasi masa depan</h3>
	</b>
</div>
	<div class="col-md-4 col-sm-4 col-lg-4 col-xs-4 col-md-offset-4" style="margin-top:0px">
	<div class="panel-body">
<form method="post" action="<?php echo base_url().'welcome/login'?>">
	<div class="form-group">
		<button type="submit" value="Login" class="btn btn-info btn-block"> Masuk </button> 
	</div>
</form>
	</div>
	</div>
</center>

<div class="footer">
<h5>Powered by <a href="<?php echo base_url().''?>">Kelompok 4</a>. All rights reserved</h5>
</div>
</body>
</html>