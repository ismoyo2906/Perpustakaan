<div class="page-header">
	<h3 class="text">Visi Dan Misi</h3>
</div>

<br>

<div class="col-sm-12 margin-bottom-40 table-responsive">
	<h4>Visi</h4>
		"Terwujudnya Indonesia Cerdas Melalui Gemar Membaca Dengan Memberdayakan Perpustakaan"
<br>
<br>
	<h4>Misi</h4>
<h5>
	<ol>
		<li>Mewujudkan koleksi nasional yang lengkap dan mutakhir;</li>
		<li>Mengembangkan layanan perpustakaan berbasis teknologi informasi dan komunikasi (TIK);</li>
		<li>Mengembangkan perpustakaan yang menjangkau masyarakat luas;</li>
		<li>Mewujudkan tenaga perpustakaan yang kompeten dan professional;</li>
		<li>Menggalakkan sosialisasi/promosi/pemasyarakatan gemar membaca;</li>
		<li>Mengembangkan infrastruktur Perpustakaan Nasional yang modern.</li>
	</ol>
</h5>
</div>