<div class="page-header">
	<h3 class="text">Selamat Datang</h3>
</div>
<div class="row">
<div class="col-lg-7">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h3 class="panel-tittle" style="font-size: 18px; font-weight: bold"<b><i class="glyphicon glyphicon-list-alt"></i> <?php echo $this->m_perpus->get_data('buku')->num_rows();?> Data Buku</h3>
			</div>
			<div class="panel-body">
				<div class="list-group">
					<?php foreach($buku as $b){ ?>
						<a href="#" class="list-group-item">
							<span class="badge"><?php if($b->lokasi == "Rak 1, Rak 2, Rak 3"){echo "selected='selected'";} echo $b->lokasi; ?></span>
							<span class="badge"><?php if($b->status_buku == 1){echo "Tersedia";}else{echo "Dipinjam";}?></span>
							<span class="badge"><?php echo $b->isbn; ?></span>
							<i class="glyphicon glyphicon-user"></i><?php echo $b->judul_buku;?>
						</a>
					<?php } ?>
				</div>
			<div class="text-right">
				<a href="<?php echo base_url().'user/buku'?>">Lihat Semua Buku<i class="glyphicon glyphicon-arrow-right"></i></a>
			</div>
		</div>
	</div>
</div>
	<div class="col-lg-5">
		<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-tittle" style="font-size: 18px; font-weight: bold"<b><i class="glyphicon glyphicon-list-alt"></i> Informasi </h3>
			</div>
				<div class="panel-body">
					<div class="list-group">
					<?php foreach($article as $r){ ?>
					<a href="<?php echo base_url().'user/informasi/'.$r->id_article;?>" class="list-group-item">
						<span class="badge"><?php echo date('d/m/Y',strtotime($r->tgl_terbit)); ?></span>
						<i></i><?php echo $r->title;?>
					</a>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</div>
<hr>